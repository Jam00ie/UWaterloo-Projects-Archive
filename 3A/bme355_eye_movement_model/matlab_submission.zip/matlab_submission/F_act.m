function f_act = F_act(l_m, l_mdot, a, C)

    f_act = a * C.F_max * F_l(l_m, C) * F_v(l_mdot, C); % (Equation 3.1)
end