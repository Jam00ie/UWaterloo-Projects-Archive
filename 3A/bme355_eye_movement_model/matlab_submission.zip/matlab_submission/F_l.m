function f_l = F_l(l_m, C)
    % (Equation 3.3)
    term = (l_m ./ C.l_opt) - 1;
    f_l = 1 - (term .^ 2);
end