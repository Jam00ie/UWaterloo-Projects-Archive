function f_pe = F_pe(l_m, C)
    % (Equation 3.17)
    scale = (180 / (pi * C.r));
    f_pe = zeros(size(l_m));

    idx1 = (l_m >= C.l_ms) & (l_m < C.l_mc);
    idx2 = l_m > C.l_mc;

    f_pe(idx1) = (C.k_ml / C.k_me) * (exp(C.k_me * scale * (l_m(idx1) - C.l_ms)) - 1);
    f_pe(idx2) = C.k_pm * scale * (l_m(idx2) - C.l_mc) + C.F_mc;
end