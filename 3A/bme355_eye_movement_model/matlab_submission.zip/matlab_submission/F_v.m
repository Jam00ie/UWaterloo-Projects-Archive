function f_v = F_v(l_md, C)
    % (Equation 3.6)
    f_v = nthroot(l_md ./ C.V_max, 3) + 1;
end