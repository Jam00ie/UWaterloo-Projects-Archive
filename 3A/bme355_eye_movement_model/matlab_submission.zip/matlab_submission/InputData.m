classdef InputData

    properties
        file_name
        raw_time_unit {mustBeNumeric}
        raw_data {mustBeNumeric}
        time {mustBeNumeric}
        position {mustBeNumeric}
        t_range {mustBeNumeric}
        fn  % struct containing pos/vel/acc/jerk functions
        display_name string
        tODE1 {mustBeNumeric}
        xODE1 {mustBeNumeric}
        tODE2 {mustBeNumeric}
        xODE2 {mustBeNumeric}
    end

    methods
    
        function obj = InputData(file_name_, display_name_, raw_time_unit_)
        % InputData Constructor
        % Inputs:
        %   file_name_ - string: path to file
        %   display_name_ - string: human-readable label
        %   raw_time_unit_ - numeric: time unit multiplier (e.g., 0.001 for ms to s)
        
        % Set default values
        if nargin < 3 || isempty(raw_time_unit_)
            raw_time_unit_ = 0.001;  % default: ms to s
        end
        if nargin < 2 || isempty(display_name_)
            display_name_ = string(file_name_);
        end
        
        if ~isfile(file_name_)
            error('File "%s" not found.', file_name_);
        end
        
        % Store properties
        obj.file_name      = file_name_;
        obj.display_name   = display_name_;
        obj.raw_time_unit  = raw_time_unit_;
        
        % Read and validate data
        obj.raw_data = readmatrix(file_name_);
        if size(obj.raw_data, 2) ~= 2
            error('Input file must have exactly two columns: [time, position].');
        end
        
        [obj.time, idx_unique] = unique(obj.raw_data(:,1), 'stable');
        obj.position = obj.raw_data(idx_unique, 2);
        obj.time = obj.time * raw_time_unit_;
        
        if obj.position(end) < 0
            obj.position = -obj.position;
        end
        
        obj.t_range = [obj.time(1), obj.time(end)];
        
        % Constants (imported from constant struct)
        C = eyeModelConstants();
        
        % Generate smoothed spline functions for theta and muscle length
        thetaLengthFns = getThetaLengthSplines(obj, C);
        
        obj.fn.theta  = thetaLengthFns.theta;
        obj.fn.theta_d  = thetaLengthFns.theta_d;
        obj.fn.theta_dd  = thetaLengthFns.theta_dd;
        
        obj.fn.l_m1 = thetaLengthFns.l_m1;
        obj.fn.l_m2 = thetaLengthFns.l_m2;
        obj.fn.l_m1d = thetaLengthFns.l_m1d;
        obj.fn.l_m2d = thetaLengthFns.l_m2d;
        obj.fn.l_m1dd = thetaLengthFns.l_m1dd;
        obj.fn.l_m2dd = thetaLengthFns.l_m2dd;
        
        % Run stepOneModel to compute F_t points
        [obj.tODE1, obj.xODE1] = computeStepOneModel(obj.t_range, obj.fn, C);
        
        % Generate smoothed spline functions for tendon force and activation
        forceActFns = getForceActSplines(obj.tODE1, obj.xODE1, obj.fn, C);
        
        obj.fn.F_t1 = forceActFns.F_t1;
        obj.fn.F_t2 = forceActFns.F_t2;
        obj.fn.F_t1d = forceActFns.F_t1d;
        obj.fn.F_t2d = forceActFns.F_t2d;
        
        obj.fn.a_1 = forceActFns.a_1;
        obj.fn.a_2 = forceActFns.a_2;
        obj.fn.a_1d = forceActFns.a_1d;
        obj.fn.a_2d = forceActFns.a_2d;
        
        % Run stepTwoModel for validation
        [obj.tODE2, obj.xODE2] = computeStepTwoModel(obj.t_range, obj.fn, C);
        end
    
    end

end
