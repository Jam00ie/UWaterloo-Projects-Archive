function k_t = K_t(F_t, C)

    if (0 <= F_t) && (F_t < C.F_tc)
        k_t = C.k_te * F_t + C.k_tl;
    else
        k_t = C.k_s;
    end % (Equation 3.11)
end