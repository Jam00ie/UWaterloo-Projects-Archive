load all data by running load_eye_data.m first

InputData.m is a class and holds all the functions needed to plot

use generateResultFigureGrid and pass it the InputData object you want to plot all the main important stuff

anyways goodnight 

