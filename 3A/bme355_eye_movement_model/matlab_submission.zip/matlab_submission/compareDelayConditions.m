function compareDelayConditions(all_data)
    output_dir = 'figs_results';
    output_pdf = fullfile(output_dir, 'delay_comparison_summary.pdf');

    if ~isfolder(output_dir)
        mkdir(output_dir);
    end

    groups = {
        'right', 'abduct', 'Right Abducting Eye';
        'left', 'adduct', 'Left Adducting Eye'
    };

    conditions = {
        'none', 'No Delay';
        'mild', 'Mild Delay';
        'clear', 'Clear Delay'
    };

    for g = 1:2
        eye_side   = groups{g, 1};
        motion_key = groups{g, 2};
        page_title = groups{g, 3};

        % Create figure
        fig = figure('Visible', 'off', 'Position', [100 100 1200 800]);
        tl = tiledlayout(fig, 2, 3, 'Padding', 'compact', 'TileSpacing', 'compact');
        title(tl, [page_title ': Delay Comparison'], ...
              'FontWeight', 'bold', 'FontSize', 16, 'Interpreter', 'none');

        % Keep track of y-limits for syncing
        theta_all = [];
        a_all = [];

        % Pre-evaluate all for shared limits
        t_all = cell(3,1);
        theta = cell(3,1);
        a1 = cell(3,1);
        a2 = cell(3,1);

        for c = 1:3
            cond_key = conditions{c,1};
            obj_name = ['data_' motion_key '_' eye_side '_' cond_key];
            obj = all_data.(obj_name);
            t_all{c} = obj.tODE2;
            theta{c} = obj.fn.theta(t_all{c});
            a1{c} = obj.fn.a_1(t_all{c});
            a2{c} = obj.fn.a_2(t_all{c});
            theta_all = [theta_all; theta{c}];
            a_all = [a_all; a1{c}; a2{c}];
        end

        % --- Precompute shared axis limits ---
        y_theta = [min(theta_all), max(theta_all)];
        y_alpha = [min(a_all), max(a_all)];

        % === Top row: θ ===
        for c = 1:3
            nexttile; hold on;
            plot(t_all{c}, theta{c}, 'k-', 'LineWidth', 1.5);
            title(['$\theta$ (' conditions{c,2} ')'], 'Interpreter', 'latex');
            ylabel('deg'); 
            grid on; axis tight; ylim(y_theta);
        end

        % === Bottom row: Activation ===
        for c = 1:3
            nexttile; hold on;
            plot(t_all{c}, a1{c}, 'b-', 'LineWidth', 1.5);
            plot(t_all{c}, a2{c}, 'r-', 'LineWidth', 1.5);
            title(['Activation (' conditions{c,2} ')'], 'Interpreter', 'latex');
            ylabel('\alpha'); legend('a_1', 'a_2');
            grid on; axis tight; ylim(y_alpha);
        end

        % Save PNG
        png_file = fullfile(output_dir, [eye_side '_eye_delay_comparison.png']);
        drawnow;
        exportgraphics(fig, png_file);

        % Append to PDF
        exportgraphics(fig, output_pdf, 'Append', g > 1);
        close(fig);
    end

    fprintf('✅ Created delay comparison PDF + PNGs in %s/\n', output_dir);
end
