function compareHealthyVsIno(all_data)
    output_dir = 'figs_results';
    output_pdf = fullfile(output_dir, 'healthy_vs_ino_summary.pdf');

    if ~isfolder(output_dir)
        mkdir(output_dir);
    end

    groups = {
        'abduct', 'Abducting';
        'adduct', 'Adducting'
    };

    for i = 1:2
        group_key = groups{i, 1};
        group_title = groups{i, 2};

        % Get objects
        healthy_obj = all_data.(['data_' group_key '_healthy']);
        ino_obj     = all_data.(['data_' group_key '_ino']);

        % Time vectors
        t_h = healthy_obj.tODE2;
        t_i = ino_obj.tODE2;

        % Values
        theta_h = healthy_obj.fn.theta(t_h);
        theta_i = ino_obj.fn.theta(t_i);

        a1_h = healthy_obj.fn.a_1(t_h);
        a2_h = healthy_obj.fn.a_2(t_h);
        a1_i = ino_obj.fn.a_1(t_i);
        a2_i = ino_obj.fn.a_2(t_i);

        % Create figure
        fig = figure('Visible', 'off', 'Position', [100 100 1000 800]);
        tl = tiledlayout(fig, 2, 2, 'Padding', 'compact', 'TileSpacing', 'compact');
        title(tl, [group_title ': Healthy vs INO'], ...
              'FontWeight', 'bold', 'FontSize', 16, 'Interpreter', 'none');

        % --- θ: Healthy ---
        ax1 = nexttile; hold on;
        plot(t_h, theta_h, 'k-', 'LineWidth', 1.5);
        title('$\theta$ (Healthy)', 'Interpreter', 'latex');
        ylabel('deg'); grid on; axis tight;

        % --- θ: INO ---
        ax2 = nexttile; hold on;
        plot(t_i, theta_i, 'k-', 'LineWidth', 1.5);
        title('$\theta$ (INO)', 'Interpreter', 'latex');
        ylabel('deg'); grid on; axis tight;

        % Match θ y-limits
        lims_theta = [min([theta_h; theta_i]), max([theta_h; theta_i])];
        ylim(ax1, lims_theta);
        ylim(ax2, lims_theta);

        % --- Activation: Healthy ---
        ax3 = nexttile; hold on;
        plot(t_h, a1_h, 'b-', 'LineWidth', 1.5);
        plot(t_h, a2_h, 'r-', 'LineWidth', 1.5);
        title('Activation (Healthy)', 'Interpreter', 'latex');
        ylabel('\alpha'); legend('a_1', 'a_2'); grid on; axis tight;

        % --- Activation: INO ---
        ax4 = nexttile; hold on;
        plot(t_i, a1_i, 'b-', 'LineWidth', 1.5);
        plot(t_i, a2_i, 'r-', 'LineWidth', 1.5);
        title('Activation (INO)', 'Interpreter', 'latex');
        ylabel('\alpha'); legend('a_1', 'a_2'); grid on; axis tight;

        % Match activation y-limits
        lims_act = [min([a1_h; a2_h; a1_i; a2_i]), max([a1_h; a2_h; a1_i; a2_i])];
        ylim(ax3, lims_act);
        ylim(ax4, lims_act);

        % Export to individual PNG
        png_filename = fullfile(output_dir, [group_key '_healthy_vs_ino.png']);
        drawnow;
        exportgraphics(fig, png_filename);

        % Append to PDF
        exportgraphics(fig, output_pdf, 'Append', i > 1);
        close(fig);
    end

    fprintf('✅ Created:\n- %s\n- Individual PNGs saved in %s/\n', output_pdf, output_dir);
end
