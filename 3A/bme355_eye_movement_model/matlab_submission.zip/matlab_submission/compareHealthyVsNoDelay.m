function compareHealthyVsNoDelay(all_data)
    output_dir = 'figs_results';
    output_pdf = fullfile(output_dir, 'healthy_vs_nodelay_summary.pdf');

    if ~isfolder(output_dir)
        mkdir(output_dir);
    end

    groups = {
        'abduct', 'right', 'Abducting';
        'adduct', 'left',  'Adducting'
    };

    for i = 1:2
        motion_key = groups{i, 1};  % 'abduct' or 'adduct'
        side_key   = groups{i, 2};  % 'right' or 'left'
        group_title = groups{i, 3}; % 'Abducting' or 'Adducting'

        % Get objects
        healthy_obj = all_data.(['data_' motion_key '_healthy']);
        nodelay_obj = all_data.(['data_' motion_key '_' side_key '_none']);

        % Time vectors
        t_h = healthy_obj.tODE2;
        t_n = nodelay_obj.tODE2;

        % Values
        theta_h = healthy_obj.fn.theta(t_h);
        theta_n = nodelay_obj.fn.theta(t_n);

        a1_h = healthy_obj.fn.a_1(t_h);
        a2_h = healthy_obj.fn.a_2(t_h);
        a1_n = nodelay_obj.fn.a_1(t_n);
        a2_n = nodelay_obj.fn.a_2(t_n);

        % Create figure
        fig = figure('Visible', 'off', 'Position', [100 100 1000 800]);
        tl = tiledlayout(fig, 2, 2, 'Padding', 'compact', 'TileSpacing', 'compact');
        title(tl, [group_title ': Healthy vs No Delay'], ...
              'FontWeight', 'bold', 'FontSize', 16, 'Interpreter', 'none');

        % --- θ: Healthy ---
        nexttile; hold on;
        plot(t_h, theta_h, 'k-', 'LineWidth', 1.5);
        title('$\theta$ (Healthy)', 'Interpreter', 'latex');
        ylabel('deg'); grid on; axis tight;

        % --- θ: No Delay ---
        nexttile; hold on;
        plot(t_n, theta_n, 'k-', 'LineWidth', 1.5);
        title('$\theta$ (No Delay)', 'Interpreter', 'latex');
        ylabel('deg'); grid on; axis tight;

        % --- Activation: Healthy ---
        nexttile; hold on;
        plot(t_h, a1_h, 'b-', 'LineWidth', 1.5);
        plot(t_h, a2_h, 'r-', 'LineWidth', 1.5);
        title('Activation (Healthy)', 'Interpreter', 'latex');
        ylabel('\alpha'); legend('a_1', 'a_2'); grid on; axis tight;

        % --- Activation: No Delay ---
        nexttile; hold on;
        plot(t_n, a1_n, 'b-', 'LineWidth', 1.5);
        plot(t_n, a2_n, 'r-', 'LineWidth', 1.5);
        title('Activation (No Delay)', 'Interpreter', 'latex');
        ylabel('\alpha'); legend('a_1', 'a_2'); grid on; axis tight;

        % Export to individual PNG
        png_filename = fullfile(output_dir, [motion_key '_healthy_vs_nodelay.png']);
        drawnow;
        exportgraphics(fig, png_filename);

        % Append to PDF
        exportgraphics(fig, output_pdf, 'Append', i > 1);
        close(fig);
    end

    fprintf('✅ Created:\n- %s\n- Individual PNGs saved in %s/\n', output_pdf, output_dir);
end
