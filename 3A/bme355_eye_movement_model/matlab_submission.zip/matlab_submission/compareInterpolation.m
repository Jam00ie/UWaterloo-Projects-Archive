function compareInterpolation(dataObj, mode, num_points)
    % compareInterpolation - Compare interpolation workflows with derivatives
    %
    % Inputs:
    %   dataObj - InputData object
    %   mode - 'derive_then_interp' (default) or 'interp_then_derive'
    %   num_points - number of interpolation points (default: 500)

    if nargin < 2
        mode = 'derive_then_interp';  % default mode
    end
    if nargin < 3
        num_points = 500;
    end

    % Get data from object
    time = dataObj.time;
    position = dataObj.position;

    % Query vector
    t_query = linspace(time(1), time(end), num_points);

    % Position interpolation
    y_linear = interp1(time, position, t_query, 'linear');
    y_pchip  = interp1(time, position, t_query, 'pchip');
    y_spline = interp1(time, position, t_query, 'spline');

    % Initialize velocity and acceleration
    v_linear = []; v_pchip = []; v_spline = [];
    a_linear = []; a_pchip = []; a_spline = [];

    switch mode
        case 'interp_then_derive'
            % Derive after interpolation
            v_linear = gradient(y_linear, t_query);
            v_pchip  = gradient(y_pchip,  t_query);
            v_spline = gradient(y_spline, t_query);

            a_linear = gradient(v_linear, t_query);
            a_pchip  = gradient(v_pchip,  t_query);
            a_spline = gradient(v_spline, t_query);

        case 'derive_then_interp'
            % Derive first from raw data
            v_raw = gradient(position, time);
            a_raw = gradient(v_raw, time);

            % Interpolate velocity and acceleration
            v_linear = interp1(time, v_raw, t_query, 'linear');
            v_pchip  = interp1(time, v_raw, t_query, 'pchip');
            v_spline = interp1(time, v_raw, t_query, 'spline');

            a_linear = interp1(time, a_raw, t_query, 'linear');
            a_pchip  = interp1(time, a_raw, t_query, 'pchip');
            a_spline = interp1(time, a_raw, t_query, 'spline');

        otherwise
            error('Invalid mode. Choose ''interp_then_derive'' or ''derive_then_interp''.');
    end

    % --- Plotting ---
    figure('Name', ['Interpolation Comparison (' mode ')'], 'NumberTitle', 'off');

    % 1. Position
    subplot(3,1,1);
    plot(time, position, 'ko', 'DisplayName', 'Original Data'); hold on;
    plot(t_query, y_linear, 'b-', 'DisplayName', 'Linear');
    plot(t_query, y_pchip,  'r--', 'DisplayName', 'PCHIP');
    plot(t_query, y_spline, 'g-.', 'DisplayName', 'Spline');
    title('Position Interpolation');
    xlabel('Time (s)'); ylabel('Position');
    legend('Location', 'best'); grid on; axis tight;

    % 2. Velocity
    subplot(3,1,2);
    plot(t_query, v_linear, 'b-', 'DisplayName', 'Linear Velocity'); hold on;
    plot(t_query, v_pchip,  'r--', 'DisplayName', 'PCHIP Velocity');
    plot(t_query, v_spline, 'g-.', 'DisplayName', 'Spline Velocity');
    title('Estimated Velocity');
    xlabel('Time (s)'); ylabel('Velocity');
    legend('Location', 'best'); grid on; axis tight;

    % 3. Acceleration
    subplot(3,1,3);
    plot(t_query, a_linear, 'b-', 'DisplayName', 'Linear Acceleration'); hold on;
    plot(t_query, a_pchip,  'r--', 'DisplayName', 'PCHIP Acceleration');
    plot(t_query, a_spline, 'g-.', 'DisplayName', 'Spline Acceleration');
    title('Estimated Acceleration');
    xlabel('Time (s)'); ylabel('Acceleration');
    legend('Location', 'best'); grid on; axis tight;

    drawnow;
end
