function [t, x] = computeStepTwoModel(t_range, fns, C)

    x0 = zeros(8, 1);
    t0 = t_range(1);  % Initial time for evaluating initial force

    F_diff0 = C.J_g * fns.theta_dd(t0) + C.B_g * fns.theta_d(t0) + C.K_g * fns.theta(t0);

    x0(1) = fns.theta(t0); % theta_0
    x0(2) = fns.theta_d(t0); % theta_d0
    x0(3) = fns.l_m1(t0); % l_m10
    x0(4) = 0; % l_m1d0
    x0(5) = fns.l_m2(t0); % l_m20
    x0(6) = 0; % l_m2d0
    x0(7) = fns.F_t1(t0); % F_t10
    x0(8) = fns.F_t2(t0); % F_t20
    %x0(7) = C.F_tp + F_diff0; % F_t10
    %x0(8) = C.F_tp - F_diff0; % F_t20

    model_handle = @(t, x) stepTwoModel(t, x, fns, C);
    options = odeset('RelTol', 1e-3,'AbsTol', 1e-8); % option structure

    [t, x] = ode45(model_handle, t_range, x0, options);
end