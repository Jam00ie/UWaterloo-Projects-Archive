function exportSpapsPlotsToPDF(all_data, output_file, num_points)
    % Export smoothed spline visualizations to a multi-page PDF
    if nargin < 3
        num_points = 1000;
    end

    fns = fieldnames(all_data);

    for i = 1:length(fns)
        obj = all_data.(fns{i});
        t = linspace(obj.t_range(1), obj.t_range(2), num_points);

        % Create figure and tiled layout
        fig = figure('Visible', 'off', 'Position', [100 100 1000 1000]);
        tl = tiledlayout(fig, 4, 2, 'Padding', 'compact', 'TileSpacing', 'compact');
        title(tl, obj.display_name, 'FontWeight', 'bold', 'FontSize', 16, 'Interpreter', 'none');

        % Evaluate everything
        theta     = obj.fn.theta(t);
        theta_d   = obj.fn.theta_d(t);
        l_m1      = obj.fn.l_m1(t);  l_m2 = obj.fn.l_m2(t);
        l_m1d     = obj.fn.l_m1d(t); l_m2d = obj.fn.l_m2d(t);
        F_t1      = obj.fn.F_t1(t);  F_t2 = obj.fn.F_t2(t);
        a_1       = obj.fn.a_1(t);   a_2 = obj.fn.a_2(t);

        % === Theta (Position)
        nexttile; hold on;
        plot(obj.time, obj.position, 'ko', 'DisplayName', 'Raw Data');
        plot(t, theta, 'b-', 'LineWidth', 1.5, 'DisplayName', '\theta (Smoothed)');
        title('\theta vs Time'); ylabel('\theta (deg)');
        legend('Location', 'southeast'); grid on; axis tight;

        % === Theta derivative
        nexttile;
        plot(t, theta_d, 'b-', 'LineWidth', 1.5);
        title('\theta'' vs Time'); ylabel('deg/s');
        grid on; axis tight;

        % === Muscle lengths (agonist & antagonist)
        nexttile;
        plot(t, l_m1, 'b-', t, l_m2, 'r--', 'LineWidth', 1.5);
        title('Muscle Lengths l_{m1}, l_{m2}'); ylabel('cm');
        legend('Agonist (l_{m1})', 'Antagonist (l_{m2})'); grid on; axis tight;

        % === Muscle length derivatives
        nexttile;
        plot(t, l_m1d, 'b-', t, l_m2d, 'r--', 'LineWidth', 1.5);
        title('Muscle Velocity l_{m1}'' , l_{m2}'''); ylabel('cm/s');
        legend('Agonist (l_{m1}'')', 'Antagonist (l_{m2}'')'); grid on; axis tight;

        % === Tendon forces
        nexttile;
        plot(t, F_t1, 'b-', t, F_t2, 'r--', 'LineWidth', 1.5);
        title('Tendon Forces F_{t1}, F_{t2}'); ylabel('Force (gt)');
        legend('Agonist (F_{t1})', 'Antagonist (F_{t2})'); grid on; axis tight;

        % === Activation
        nexttile;
        plot(t, a_1, 'b-', t, a_2, 'r--', 'LineWidth', 1.5);
        title('Activation a_1, a_2'); ylabel('Activation \alpha');
        legend('Agonist (a_1)', 'Antagonist (a_2)'); grid on; axis tight;

        % Fill remaining plots or leave empty
        for k = 1:8 - 6
            nexttile;
            axis off;
        end

        % Export figure to PDF
        exportgraphics(fig, output_file, 'Append', i > 1);
        close(fig);
    end

    fprintf('✅ Export complete: %s\n', output_file);
end
