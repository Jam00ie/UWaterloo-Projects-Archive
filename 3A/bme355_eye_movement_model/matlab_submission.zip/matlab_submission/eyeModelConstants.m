function C = eyeModelConstants()
% eyeModelConstants - Returns a struct of parameter values 

% From McSpadden's Complete Model
C.r = 1.24; % radius of globe (cm)
C.J_g = 6e-5; % globe rotational inertia (gt * s^2 / deg)
C.B_g = 0.0158; % globe/orbit viscosity (gt * s / deg)
C.K_g = 0.79; % globe/orbit elasticity (gt / deg)
C.B_pm = 0.06; % passive muscle viscosity (gt * s / deg)
C.M = 0.748; % muscle mass (g)
C.F_max = 100.0; % maximum isometric force (gt)
C.l_mp = 4.0; % primary muscle length (cm)
C.l_opt = 4.65; % optimal muscle length (cm)
C.l_ms = 3.7; % muscle slack length (cm)
C.l_mc = 4.8; % muscle length where passive elasticity becomes linear (cm)
C.k_me = 0.0387; % muscle exponential shape parameter (1 / deg)
C.k_pm = 0.9; % linear passive muscle elasticity (gt / deg)
C.k_ml = 0.126; % minimum passive muscle elasticity (gt / deg)
C.F_mc = 20.0; % force level where passive elasticity becomes linear (gt)
C.w = 0.5; % width of force-length curve
C.V_max = 5689.0; % max muscle velocity (deg / s)
C.k_s = 2.5; % linear tendon elasticity (gt / deg)
C.k_tl = 1.5; % minimum tendon elasticity (gt / deg)
C.k_te = 0.0333; % tendon exponential shape parameter (1 / deg)
C.l_ts = 0.2; % tendon slack length (cm)
C.l_tc = 0.532; % tendon length where elasticity becomes linear (cm)
C.F_tc = 30.0; % force level where tendon elasticity becomes linear (gt)

C.F_tp = 20; % tendon force at primary position at rest (gt)

end
