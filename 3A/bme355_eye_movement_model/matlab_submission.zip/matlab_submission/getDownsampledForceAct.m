function [t_ds, x_ds] = getDownsampledForceAct(t, x, fns, C)
    % Compute F_t1 & F_t2
    F_diff = C.J_g * fns.theta_dd(t) + C.B_g .* fns.theta_d(t) + C.K_g .* fns.theta(t);
    [F_t1, F_t2] = scaleForces(F_diff, x(:,1), x(:,2));

    % Compute a_1 & a_2
    a_1 = (F_t1 - ((C.M / 980) .* fns.l_m1dd(t)) - ...
           (C.B_pm * (180 / (pi * C.r)) .* fns.l_m1d(t)) - ...
           F_pe(fns.l_m1(t), C)) ./ ...
           (C.F_max .* F_l(fns.l_m1(t), C) .* F_v(fns.l_m1d(t), C));

    a_2 = (F_t2 - ((C.M / 980) .* fns.l_m2dd(t)) - ...
           (C.B_pm * (180 / (pi * C.r)) .* fns.l_m2d(t)) - ...
           F_pe(fns.l_m2(t), C)) ./ ...
           (C.F_max .* F_l(fns.l_m2(t), C) .* F_v(fns.l_m2d(t), C));

    % --- Scale a_1 so that max becomes 1, preserve a_1(1)
    %scale_1 = (1 - a_1(1)) / (max(a_1) - a_1(1));
    %delta_1 = a_1(1) - scale_1 * a_1(1);
    %a_1 = scale_1 * a_1 + delta_1;
    
    % --- Scale a_2 so that min becomes 0, preserve a_2(1)
    %scale_2 = a_2(1) / (a_2(1) - min(a_2));
    %delta_2 = -scale_2 * min(a_2);
    %a_2 = scale_2 * a_2 + delta_2;

    % --- Downsample by time spacing ---
    min_dt = 0.005;
    t_ds = t(1);
    idx_ds = 1;

    for i = 2:length(t)-1  % leave room to manually add last point
        if (t(i) - t_ds(end)) >= min_dt
            t_ds(end+1) = t(i);       %#ok<AGROW>
            idx_ds(end+1) = i;        %#ok<AGROW>
        end
    end

    % Ensure last point is included
    if idx_ds(end) ~= length(t)
        t_ds(end+1) = t(end);
        idx_ds(end+1) = length(t);
    end

    % Stack downsampled values
    x_ds = [F_t1(idx_ds), F_t2(idx_ds), a_1(idx_ds), a_2(idx_ds)];
end
