function forceActFns = getForceActSplines(t, x, fns, C, smoothing_tolerance)

    if nargin < 5
        smoothing_tolerance = 0.000001;  % default
    end

    % --- Use external downsampling function ---
    [t_ds, x_ds] = getDownsampledForceAct(t, x, fns, C);

    F_t1_ds = x_ds(:,1);
    F_t2_ds = x_ds(:,2);
    a_1_ds  = x_ds(:,3);
    a_2_ds  = x_ds(:,4);

    % --- Generate force splines ---
    sp1 = spaps(t_ds, F_t1_ds, smoothing_tolerance);
    sp2 = spaps(t_ds, F_t2_ds, smoothing_tolerance);

    forceActFns.F_t1 = @(t) fnval(sp1, t);
    forceActFns.F_t2 = @(t) fnval(sp2, t);
    forceActFns.F_t1d = @(t) fnval(fnder(sp1, 1), t);
    forceActFns.F_t2d = @(t) fnval(fnder(sp2, 1), t);

    % --- Generate activation splines ---
    sp3 = spaps(t_ds, a_1_ds, smoothing_tolerance);
    sp4 = spaps(t_ds, a_2_ds, smoothing_tolerance);

    forceActFns.a_1 = @(t) fnval(sp3, t);
    forceActFns.a_2 = @(t) fnval(sp4, t);
    forceActFns.a_1d = @(t) fnval(fnder(sp3, 1), t);
    forceActFns.a_2d = @(t) fnval(fnder(sp4, 1), t);
end
