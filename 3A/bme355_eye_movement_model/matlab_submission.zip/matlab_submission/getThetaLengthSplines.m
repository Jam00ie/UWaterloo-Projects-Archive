function thetaLengthFns = getThetaLengthSplines(dataObj, C, smoothing_tolerance)
    if nargin < 3
        smoothing_tolerance = 0.001;  % default
    end

    sp = spaps(dataObj.time, dataObj.position, smoothing_tolerance);

    thetaLengthFns.theta  = @(t) fnval(sp, t);
    thetaLengthFns.theta_d  = @(t) fnval(fnder(sp, 1), t);
    thetaLengthFns.theta_dd  = @(t) fnval(fnder(sp, 2), t);

    % Compute approximate l_m1 and l_m2 treating l_tm1 and l_tm2 as surrogates for l_m1 and l_m2
    thetaLengthFns.l_m1 = @(t) C.l_mp - (pi * C.r / 180) * thetaLengthFns.theta(t); % Equation 4.2
    thetaLengthFns.l_m2 = @(t) C.l_mp + (pi * C.r / 180) * thetaLengthFns.theta(t); % Equation 4.3

    thetaLengthFns.l_m1d = @(t) -(pi * C.r / 180) * thetaLengthFns.theta_d(t);
    thetaLengthFns.l_m2d = @(t)  (pi * C.r / 180) * thetaLengthFns.theta_d(t);

    thetaLengthFns.l_m1dd = @(t) -(pi * C.r / 180) * thetaLengthFns.theta_dd(t);
    thetaLengthFns.l_m2dd = @(t)  (pi * C.r / 180) * thetaLengthFns.theta_dd(t);
end