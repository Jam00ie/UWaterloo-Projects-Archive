% load_eye_data.m
% Loads all eye movement datasets and stores them in a structured format

% === Define base path to raw data folder ===
data_path = fullfile(pwd, 'raw_data');

% === Load data files ===
data_abduct_healthy     = InputData(fullfile(data_path, ...
    'Matta_abducting_healthy_20.xlsx'), "Abducting Eye, Healthy");
fprintf('Loaded data_abduct_healthy\n');
data_adduct_healthy     = InputData(fullfile(data_path, ...
    'Matta_adducting_healthy_20.xlsx'), "Adducting Eye, Healthy");
fprintf('Loaded data_adduct_healthy\n');

data_abduct_ino         = InputData(fullfile(data_path, ...
    'Matta_abducting_INO_20.xlsx'), "Abducting Eye, INO");
fprintf('Loaded data_abduct_ino\n');
data_adduct_ino         = InputData(fullfile(data_path, ...
    'Matta_adducting_INO_20.xlsx'), "Adducting Eye, INO");
fprintf('Loaded data_adduct_ino\n');

data_abduct_right_none  = InputData(fullfile(data_path, ...
    'No_Delay_Left_Eye.csv'), "Abducting Right Eye, INO (No Delay)");
fprintf('Loaded data_abduct_right_none\n');
data_adduct_left_none   = InputData(fullfile(data_path, ...
    'No_Delay_Right_Eye.csv'), "Adducting Left Eye, INO (No Delay)");
fprintf('Loaded data_adduct_left_none\n');

data_abduct_right_mild  = InputData(fullfile(data_path, ...
    'Mild_Delay_Left_Eye.csv'), "Abducting Right Eye, INO (Mild Delay)");
fprintf('Loaded data_abduct_right_mild\n');
data_adduct_left_mild   = InputData(fullfile(data_path, ...
    'Mild_Delay_Right_Eye.csv'), "Adducting Left Eye, INO (Mild Delay)");
fprintf('Loaded data_adduct_left_mild\n');

data_abduct_right_clear = InputData(fullfile(data_path, ...
    'Clear_Delay_Left_Eye.csv'), "Abducting Right Eye, INO (Clear Delay)");
fprintf('Loaded data_abduct_right_clear\n');
data_adduct_left_clear  = InputData(fullfile(data_path, ...
    'Clear_Delay_Right_Eye.csv'), "Abducting Left Eye, INO (Clear Delay)");
fprintf('Loaded data_adduct_left_clear\n');

% === Preserve insertion order using a manual list ===
ordered_vars = {
    'data_abduct_healthy'
    'data_adduct_healthy'
    'data_abduct_ino'
    'data_adduct_ino'
    'data_abduct_right_none'
    'data_abduct_right_mild'
    'data_abduct_right_clear'
    'data_adduct_left_none'
    'data_adduct_left_mild'
    'data_adduct_left_clear'
};

all_data = struct();
for i = 1:length(ordered_vars)
    all_data.(ordered_vars{i}) = eval(ordered_vars{i});
end

fprintf('✅ Loading complete!\n');