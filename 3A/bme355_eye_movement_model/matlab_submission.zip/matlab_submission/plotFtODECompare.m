function plotFtODECompare(dataObj)
    % plotFtODECompare - Compares raw and scaled tendon force estimates from stepOneModel
    % Inputs:
    %   dataObj - an InputData object

    C = eyeModelConstants();
    [tODE, xODE] = computeStepOneModel(dataObj.t_range, dataObj.fn, C);

    F_t1_ = xODE(:,1); 
    F_t2_ = xODE(:,2);
    F_diff_ = F_t1_ - F_t2_;

    F_diff = C.J_g * dataObj.fn.theta_dd(tODE) + C.B_g * dataObj.fn.theta_d(tODE) + C.K_g * dataObj.fn.theta(tODE);

    %[F_t1, F_t2] = scaleForces(F_diff, F_t1_, F_t2_);

    % Scaling
    ratio_i = F_diff(1) / F_diff_(1);
    ratio_f = F_diff(end) / F_diff_(end);

    F_t1_i = F_t1_(1) * ratio_i;
    F_t2_i = F_t2_(1) * ratio_i;

    F_t1_f = F_t1_(end) * ratio_f;
    F_t2_f = F_t2_(end) * ratio_f;

    F_t1 = F_t1_ - F_t1_(1) + F_t1_i;
    F_t2 = F_t2_ - F_t2_(1) + F_t2_i;

    scale_1 = (F_t1_f - F_t1_i) / (F_t1(end) - F_t1(1));
    F_t1 = (F_t1 - F_t1(1)) * scale_1 + F_t1_i;
    
    scale_2 = (F_t2_f - F_t2_i) / (F_t2(end) - F_t2(1));
    F_t2 = (F_t2 - F_t2(1)) * scale_2 + F_t2_i;


    % === Plotting ===
    figure;

    % F_t1 Comparison
    subplot(3,1,1);
    plot(tODE, F_t1_, 'b--', 'DisplayName', 'Raw F_{t1}');
    hold on;
    plot(tODE, F_t1, 'b-', 'DisplayName', 'Scaled F_{t1}');
    title(sprintf('%s - F_{t1} Comparison', dataObj.display_name));
    xlabel('Time (s)');
    ylabel('Force (gt)');
    legend; grid on;

    % F_t2 Comparison
    subplot(3,1,2);
    plot(tODE, F_t2_, 'r--', 'DisplayName', 'Raw F_{t2}');
    hold on;
    plot(tODE, F_t2, 'r-', 'DisplayName', 'Scaled F_{t2}');
    title(sprintf('%s - F_{t2} Comparison', dataObj.display_name));
    xlabel('Time (s)');
    ylabel('Force (gt)');
    legend; grid on;

    % F_diff vs Denominator
    subplot(3,1,3);
    plot(tODE, F_diff, 'k-', 'DisplayName', 'F_{diff}(t)');
    hold on;
    plot(tODE, F_diff_, 'm--', 'DisplayName', 'F_{t1}^{raw} - F_{t2}^{raw}');
    plot(tODE, alpha, 'm', 'LineWidth', 1.5, 'DisplayName','α');
    title('Dynamic Balance Comparison');
    xlabel('Time (s)');
    ylabel('Force Difference (gt)');
    legend; grid on;
end