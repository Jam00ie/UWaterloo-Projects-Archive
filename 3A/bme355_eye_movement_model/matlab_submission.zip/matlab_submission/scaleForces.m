function [F_t1, F_t2] = scaleForces(F_diff, F_t1_, F_t2_)

    % --- Step 1: Compute net unscaled force difference ---
    F_diff_ = F_t1_ - F_t2_;

    % --- Step 2: Compute scaling ratios for initial and final points ---
    ratio_i = F_diff(1)   / F_diff_(1);
    ratio_f = F_diff(end) / F_diff_(end);

    % --- Step 3: Compute target start and end values for F_t1 and F_t2 ---
    F_t1_i = F_t1_(1) * ratio_i;
    F_t2_i = F_t2_(1) * ratio_i;

    F_t1_f = F_t1_(end) * ratio_f;
    F_t2_f = F_t2_(end) * ratio_f;

    % --- Step 4: Shift to match initial values ---
    F_t1 = F_t1_ - F_t1_(1) + F_t1_i;
    F_t2 = F_t2_ - F_t2_(1) + F_t2_i;

    % --- Step 5: Scale to match final values, preserving new initial values ---
    scale_1 = (F_t1_f - F_t1_i) / (F_t1(end) - F_t1(1));
    F_t1 = (F_t1 - F_t1(1)) * scale_1 + F_t1_i;

    scale_2 = (F_t2_f - F_t2_i) / (F_t2(end) - F_t2(1));
    F_t2 = (F_t2 - F_t2(1)) * scale_2 + F_t2_i;
end
