function [dxdt] = stepOneModel(t, x, fns, C)
    
    theta_d = fns.theta(t);
    l_m1d = fns.l_m1d(t);
    l_m2d = fns.l_m2d(t);
    
    dxdt = zeros(2, 1);
    
    dxdt(1) = K_t(x(1), C) * ((-1 * theta_d) - (180 / (pi * C.r)) * l_m1d);
    dxdt(2) = K_t(x(2), C) * ((+1 * theta_d) - (180 / (pi * C.r)) * l_m2d);
end