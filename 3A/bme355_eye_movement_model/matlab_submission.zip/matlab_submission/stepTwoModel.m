function [dxdt] = stepTwoModel(t, x, fns, C)
    
    a_1 = fns.a_1(t);
    a_2 = fns.a_2(t);
    
    dxdt = zeros(8, 1);
    
    dxdt(1) = x(2);
    dxdt(2) = (1 / C.J_g) * (x(7) - x(8) - (C.B_g * x(2)) - (C.K_g * x(1)));
    dxdt(3) = x(4);
    dxdt(4) = (980 / C.M) * (x(7) - F_act(x(3), x(4), a_1, C) - F_pe(x(3), C) - C.B_pm * (180 / (pi * C.r)) * x(4));
    dxdt(5) = x(6);
    dxdt(6) = (980 / C.M) * (x(8) - F_act(x(5), x(6), a_2, C) - F_pe(x(5), C) - C.B_pm * (180 / (pi * C.r)) * x(6));
    dxdt(7) = K_t(x(7), C) * ((-1 * x(2)) - (180 / (pi * C.r)) * x(4));
    dxdt(8) = K_t(x(8), C) * ((+1 * x(2)) - (180 / (pi * C.r)) * x(6));
end