function visualizeForceActivation_GUI(dataObj)

    [t, x] = getDownsampledForceAct(dataObj.tODE1, dataObj.xODE1, dataObj.fn, eyeModelConstants());

    raw.F_t1 = x(:,1);
    raw.F_t2 = x(:,2);
    raw.a_1 = x(:,3);
    raw.a_2 = x(:,4);

    smoothing_options = {'0.1', '0.01', '0.001', '0.0005', '0.0001', '0.00005', '0.00001', '0.000005', '0.000001'};
    default_index = find(strcmp(smoothing_options, '0.001'));

    fig = figure('Name', sprintf('%s - Force & Activation Spline Fitting', dataObj.display_name), ...
                 'NumberTitle', 'off', ...
                 'Position', [100, 100, 1200, 800]);

    t_panel = tiledlayout(3,2,'Padding','compact','TileSpacing','compact');

    uicontrol('Style', 'text', 'String', 'Smoothing Tolerance:', ...
              'Units', 'normalized', 'Position', [0.01 0.95 0.15 0.03], ...
              'HorizontalAlignment', 'left', 'FontWeight', 'bold');

    popup = uicontrol('Style', 'popupmenu', 'String', smoothing_options, ...
                      'Units', 'normalized', 'Position', [0.17 0.95 0.1 0.04], ...
                      'Value', default_index, 'Callback', @updatePlots);

    updatePlots();

    function updatePlots(~,~)
        smoothing_tolerance = str2double(smoothing_options{popup.Value});
        delete(allchild(t_panel));  % deletes all axes inside the tiled layout

        t_dense = linspace(t(1), t(end), 1000);

        sp1 = spaps(t, raw.F_t1, smoothing_tolerance);
        sp2 = spaps(t, raw.F_t2, smoothing_tolerance);
        sp3 = spaps(t, raw.a_1, smoothing_tolerance);
        sp4 = spaps(t, raw.a_2, smoothing_tolerance);

        F_t1_fit = fnval(sp1, t_dense);
        F_t2_fit = fnval(sp2, t_dense);
        F_t1d_fit = fnval(fnder(sp1, 1), t_dense);
        F_t2d_fit = fnval(fnder(sp2, 1), t_dense);

        a_1_fit = fnval(sp3, t_dense);
        a_2_fit = fnval(sp4, t_dense);
        a_1d_fit = fnval(fnder(sp3, 1), t_dense);
        a_2d_fit = fnval(fnder(sp4, 1), t_dense);

        nexttile
        plot(t, raw.F_t1, 'bo', t_dense, F_t1_fit, 'b-', 'LineWidth', 1.5);
        title('F_{t1} vs Time'); ylabel('Force (gt)'); grid on;

        nexttile
        plot(t, raw.F_t2, 'ro', t_dense, F_t2_fit, 'r-', 'LineWidth', 1.5);
        title('F_{t2} vs Time'); ylabel('Force (gt)'); grid on;

        nexttile
        plot(t_dense, F_t1d_fit, 'b-', t_dense, F_t2d_fit, 'r-', 'LineWidth', 1.5);
        title('Force Derivatives'); ylabel('dF/dt'); legend('F_{t1}''','F_{t2}'''); grid on;

        nexttile
        plot(t, raw.a_1, 'bo', t_dense, a_1_fit, 'b-', ...
             t, raw.a_2, 'ro', t_dense, a_2_fit, 'r-', 'LineWidth', 1.5);
        title('Activation a_1 and a_2'); ylabel('Activation'); grid on;

        nexttile
        plot(t_dense, a_1d_fit, 'b-', t_dense, a_2d_fit, 'r-', 'LineWidth', 1.5);
        title('Activation Derivatives'); ylabel('da/dt'); legend('a_1''','a_2'''); grid on;

        nexttile
        plot(t_dense, F_t1_fit - F_t2_fit, 'k-', 'LineWidth', 1.5);
        title('F_{t1} - F_{t2}'); ylabel('Force Diff'); grid on;

        xlabel('Time (s)');
    end
end
