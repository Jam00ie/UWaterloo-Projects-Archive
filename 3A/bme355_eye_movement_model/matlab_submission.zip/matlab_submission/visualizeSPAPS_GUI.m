function visualizeSPAPS_GUI(dataObj, num_points)
    % visualizeSPAPS_GUI - Visualize position, velocity, acceleration, and jerk using spaps
    %
    % Inputs:
    %   dataObj    - InputData object
    %   num_points - Number of query points (default: 1000)

    if nargin < 2
        num_points = 1000;
    end

    % Raw data
    t_raw = dataObj.time;
    y_raw = dataObj.position;
    t_query = linspace(t_raw(1), t_raw(end), num_points);

    % Create figure
    fig = uifigure('Name', 'SPAPS Smoothing GUI', 'Position', [100 100 1000 920]);

    % Axes
    ax1 = uiaxes(fig, 'Position', [50 700 900 180]);  % Position
    ax2 = uiaxes(fig, 'Position', [50 510 900 180]);  % Velocity
    ax3 = uiaxes(fig, 'Position', [50 320 900 180]);  % Acceleration
    ax4 = uiaxes(fig, 'Position', [50 130 900 180]);  % Jerk

    % === UI Controls ===

    % File label
    [~, fname, ext] = fileparts(dataObj.file_name);
    uilabel(fig, ...
        'Position', [400 880 300 22], ...
        'Text', ['Data File: ', fname, ext], ...
        'FontWeight', 'bold', ...
        'HorizontalAlignment', 'center');

    % Tolerance label
    uilabel(fig, ...
        'Position', [50 860 150 22], ...
        'Text', 'Error Tolerance:', ...
        'Tooltip', 'The higher the tolerance, the looser the fit. Lower values follow the data more closely.');

    % Dropdown of tolerance options (fine-grained)
    tolerance_values = [0.1, 0.01, 0.001, 0.00075, 0.0005, 0.00025, 0.0001];
    tolerance_dropdown = uidropdown(fig, ...
        'Position', [180 855 100 30], ...
        'Items', compose('%.5f', tolerance_values), ...
        'Value', '0.00050', ...
        'ValueChangedFcn', @(src, event) updatePlots(str2double(src.Value)));

    % Fit error display
    error_label = uilabel(fig, ...
        'Position', [300 855 300 22], ...
        'Text', '', ...
        'FontAngle', 'italic', ...
        'FontColor', [0.3 0.3 0.3]);

    % === Initial plot
    updatePlots(0.00050);

    % === Main plotting function
    function updatePlots(tol)
        % Fit spaps spline
        [sp, fit_error] = spaps(t_raw, y_raw, tol);

        % Derivatives
        y_smooth = fnval(sp, t_query);
        v_smooth = fnval(fnder(sp, 1), t_query);
        a_smooth = fnval(fnder(sp, 2), t_query);
        j_smooth = fnval(fnder(sp, 3), t_query);

        % Compute RMS error over original points
        y_fit_at_raw = fnval(sp, t_raw);
        rms_error = sqrt(mean((y_fit_at_raw - y_raw).^2));
        error_label.Text = sprintf('RMS fit error: %.6g', rms_error);

        % === Plot Position
        plot(ax1, t_raw, y_raw, 'ko', ...
                  t_query, y_smooth, 'b-', 'LineWidth', 1.5);
        title(ax1, sprintf('Position (Tolerance = %.5f)', tol));
        xlabel(ax1, 'Time (s)'); ylabel(ax1, 'Position');
        legend(ax1, 'Raw Data', 'Smoothed Spline', 'Location', 'best');
        grid(ax1, 'on'); axis(ax1, 'tight');

        % === Plot Velocity
        plot(ax2, t_query, v_smooth, 'b-', 'LineWidth', 1.5);
        title(ax2, 'Velocity (1st Derivative)');
        xlabel(ax2, 'Time (s)'); ylabel(ax2, 'Velocity');
        legend(ax2, 'Smoothed Velocity', 'Location', 'best');
        grid(ax2, 'on'); axis(ax2, 'tight');

        % === Plot Acceleration
        plot(ax3, t_query, a_smooth, 'b-', 'LineWidth', 1.5);
        title(ax3, 'Acceleration (2nd Derivative)');
        xlabel(ax3, 'Time (s)'); ylabel(ax3, 'Acceleration');
        legend(ax3, 'Smoothed Acceleration', 'Location', 'best');
        grid(ax3, 'on'); axis(ax3, 'tight');

        % === Plot Jerk
        plot(ax4, t_query, j_smooth, 'b-', 'LineWidth', 1.5);
        title(ax4, 'Jerk (3rd Derivative)');
        xlabel(ax4, 'Time (s)'); ylabel(ax4, 'Jerk');
        legend(ax4, 'Smoothed Jerk', 'Location', 'best');
        grid(ax4, 'on'); axis(ax4, 'tight');
    end
end
