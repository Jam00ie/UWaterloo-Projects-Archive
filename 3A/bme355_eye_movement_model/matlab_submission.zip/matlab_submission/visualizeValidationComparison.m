function visualizeValidationComparison(obj)
    % Visualizes ODE outputs vs inputs used for activation for a single InputData object

    t = obj.tODE2;
    x = obj.xODE2;

    % ODE outputs
    theta   = x(:,1);  theta_d = x(:,2);
    l_m1    = x(:,3);  l_m1d   = x(:,4);
    l_m2    = x(:,5);  l_m2d   = x(:,6);
    F_t1    = x(:,7);  F_t2    = x(:,8);

    % Input splines
    theta_in   = obj.fn.theta(t);
    theta_d_in = obj.fn.theta_d(t);
    l_m1_in    = obj.fn.l_m1(t);  l_m1d_in = obj.fn.l_m1d(t);
    l_m2_in    = obj.fn.l_m2(t);  l_m2d_in = obj.fn.l_m2d(t);
    F_t1_in    = obj.fn.F_t1(t);  F_t2_in  = obj.fn.F_t2(t);
    a_1        = obj.fn.a_1(t);   a_2      = obj.fn.a_2(t);

    % Create on-screen figure with 3x2 layout
    fig = figure('Visible', 'on', 'Position', [100 100 1000 800]);
    tl = tiledlayout(fig, 3, 2, 'Padding', 'compact', 'TileSpacing', 'compact');
    title(tl, obj.display_name, 'FontWeight', 'bold', 'FontSize', 16, 'Interpreter', 'none');

    % --- θ ---
    nexttile; hold on;
    plot(t, theta, 'b-', 'LineWidth', 1.5);
    plot(t, theta_in, 'b:', 'LineWidth', 1.5);
    title('\theta (Agonist)'); ylabel('deg'); grid on; axis tight;

    % --- θ' ---
    nexttile; hold on;
    plot(t, theta_d, 'b-', 'LineWidth', 1.5);
    plot(t, theta_d_in, 'b:', 'LineWidth', 1.5);
    title('\theta'' (Agonist)'); ylabel('deg/s'); grid on; axis tight;

    % --- Muscle lengths ---
    nexttile; hold on;
    plot(t, l_m1, 'b-',  t, l_m2, 'r-',  'LineWidth', 1.5);    % ODE
    plot(t, l_m1_in, 'b:', t, l_m2_in, 'r:', 'LineWidth', 1.5); % Input
    title('Muscle Lengths (l_{m1}, l_{m2})'); ylabel('cm'); grid on; axis tight;

    % --- Muscle velocities ---
    nexttile; hold on;
    plot(t, l_m1d, 'b-',  t, l_m2d, 'r-',  'LineWidth', 1.5);    % ODE
    plot(t, l_m1d_in, 'b:', t, l_m2d_in, 'r:', 'LineWidth', 1.5); % Input
    title('Muscle Velocities (l_{m1}'', l_{m2}'')'); ylabel('cm/s'); grid on; axis tight;

    % --- Tendon forces ---
    nexttile; hold on;
    plot(t, F_t1, 'b-',  t, F_t2, 'r-',  'LineWidth', 1.5);    % ODE
    plot(t, F_t1_in, 'b:', t, F_t2_in, 'r:', 'LineWidth', 1.5); % Input
    title('Tendon Forces (F_{t1}, F_{t2})'); ylabel('Force (gt)'); grid on; axis tight;

    % --- Activation ---
    nexttile; hold on;
    plot(t, a_1, 'b-', 'LineWidth', 1.5);
    plot(t, a_2, 'r-', 'LineWidth', 1.5);
    title('Activations a_1 (blue) and a_2 (red)'); ylabel('\alpha'); grid on; axis tight;

    fprintf('📊 Visualization complete for: %s\n', obj.display_name);
end
